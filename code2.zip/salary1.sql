/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50734
 Source Host           : localhost:3306
 Source Schema         : salary

 Target Server Type    : MySQL
 Target Server Version : 50734
 File Encoding         : 65001

 Date: 28/09/2022 22:34:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `param_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'key',
  `param_value` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'value',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态   0：隐藏   1：显示',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `param_key`(`param_key`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统配置信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_config
-- ----------------------------
INSERT INTO `sys_config` VALUES (1, 'CLOUD_STORAGE_CONFIG_KEY', '{\"aliyunAccessKeyId\":\"\",\"aliyunAccessKeySecret\":\"\",\"aliyunBucketName\":\"\",\"aliyunDomain\":\"\",\"aliyunEndPoint\":\"\",\"aliyunPrefix\":\"\",\"qcloudBucketName\":\"\",\"qcloudDomain\":\"\",\"qcloudPrefix\":\"\",\"qcloudSecretId\":\"\",\"qcloudSecretKey\":\"\",\"qiniuAccessKey\":\"NrgMfABZxWLo5B-YYSjoE8-AZ1EISdi1Z3ubLOeZ\",\"qiniuBucketName\":\"ios-app\",\"qiniuDomain\":\"http://7xqbwh.dl1.z0.glb.clouddn.com\",\"qiniuPrefix\":\"upload\",\"qiniuSecretKey\":\"uIwJHevMRWU0VLxFvgy0tAcOdGqasdtVlJkdy6vV\",\"type\":1}', 0, '云存储配置信息');

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept`  (
  `dept_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NULL DEFAULT NULL COMMENT '上级部门ID，一级部门为0',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '部门名称',
  `order_num` int(11) NULL DEFAULT NULL COMMENT '排序',
  `del_flag` tinyint(4) NULL DEFAULT 0 COMMENT '是否删除  -1：已删除  0：正常',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '部门管理' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_dept
-- ----------------------------
INSERT INTO `sys_dept` VALUES (1, 0, '某某公司', 0, 0);
INSERT INTO `sys_dept` VALUES (2, 1, '长沙分公司', 1, -1);
INSERT INTO `sys_dept` VALUES (3, 1, '上海分公司', 2, -1);
INSERT INTO `sys_dept` VALUES (4, 3, '技术部', 0, -1);
INSERT INTO `sys_dept` VALUES (5, 3, '销售部', 1, -1);
INSERT INTO `sys_dept` VALUES (6, 1, '研发部', 0, -1);

-- ----------------------------
-- Table structure for sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict`;
CREATE TABLE `sys_dict`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典名称',
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典类型',
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典码',
  `value` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典值',
  `order_num` int(11) NULL DEFAULT 0 COMMENT '排序',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `del_flag` tinyint(4) NULL DEFAULT 0 COMMENT '删除标记  -1：已删除  0：正常',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `type`(`type`, `code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '数据字典表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_dict
-- ----------------------------
INSERT INTO `sys_dict` VALUES (1, '性别', 'sex', '0', '女', 0, NULL, 0);
INSERT INTO `sys_dict` VALUES (2, '性别', 'sex', '1', '男', 1, NULL, 0);
INSERT INTO `sys_dict` VALUES (3, '性别', 'sex', '2', '未知', 3, NULL, -1);

-- ----------------------------
-- Table structure for sys_item
-- ----------------------------
DROP TABLE IF EXISTS `sys_item`;
CREATE TABLE `sys_item`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工资项',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '工资项' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_item
-- ----------------------------
INSERT INTO `sys_item` VALUES (4, '测试项');

-- ----------------------------
-- Table structure for sys_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户操作',
  `method` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求参数',
  `time` bigint(20) NOT NULL COMMENT '执行时长(毫秒)',
  `ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'IP地址',
  `create_date` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统日志' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_log
-- ----------------------------
INSERT INTO `sys_log` VALUES (1, 'admin', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '6', 0, '0:0:0:0:0:0:0:1', '2022-09-21 14:37:14');
INSERT INTO `sys_log` VALUES (2, 'admin', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '7', 0, '0:0:0:0:0:0:0:1', '2022-09-21 14:37:18');
INSERT INTO `sys_log` VALUES (3, 'admin', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '{\"userId\":1,\"username\":\"dev\",\"password\":\"1e4730675f1e46f44e1f4cc85a285f1f2cca2d7fbb344d552c0dc34aa89e148a\",\"salt\":\"YzcmCZNvbXocrsz9dm8e\",\"email\":\"root@renren.io\",\"mobile\":\"13612345678\",\"status\":1,\"roleIdList\":[],\"createTime\":\"Nov 11, 2016 11:11:11 AM\",\"deptId\":1,\"deptName\":\"人人开源集团\"}', 41, '0:0:0:0:0:0:0:1', '2022-09-21 14:39:36');
INSERT INTO `sys_log` VALUES (4, 'dev', '保存角色', 'io.renren.modules.sys.controller.SysRoleController.save()', '{\"roleId\":1,\"roleName\":\"admin\",\"deptId\":6,\"deptName\":\"研发部\",\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,5,27,29,31,32,33,34,35,36,37,38,39,40],\"deptIdList\":[6],\"createTime\":\"Sep 21, 2022 2:42:00 PM\"}', 66, '0:0:0:0:0:0:0:1', '2022-09-21 14:42:01');
INSERT INTO `sys_log` VALUES (5, 'dev', '保存角色', 'io.renren.modules.sys.controller.SysRoleController.save()', '{\"roleId\":2,\"roleName\":\"user\",\"remark\":\"普通用户\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:42:24 PM\"}', 16, '0:0:0:0:0:0:0:1', '2022-09-21 14:42:25');
INSERT INTO `sys_log` VALUES (6, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":1,\"roleName\":\"admin\",\"deptId\":6,\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,5,27,29,31,32,33,34,35,36,37,38,39,40],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:42:01 PM\"}', 54, '0:0:0:0:0:0:0:1', '2022-09-21 14:42:37');
INSERT INTO `sys_log` VALUES (7, 'dev', '删除角色', 'io.renren.modules.sys.controller.SysRoleController.delete()', '[1]', 13, '0:0:0:0:0:0:0:1', '2022-09-21 14:42:50');
INSERT INTO `sys_log` VALUES (8, 'dev', '保存角色', 'io.renren.modules.sys.controller.SysRoleController.save()', '{\"roleId\":3,\"roleName\":\"admin\",\"remark\":\"管理员\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[1,2,15,16,17,18,3,19,20,21,22,5,27,29,31,32,33,34,35,36,37,38,39,40],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:43:10 PM\"}', 41, '0:0:0:0:0:0:0:1', '2022-09-21 14:43:11');
INSERT INTO `sys_log` VALUES (9, 'dev', '保存用户', 'io.renren.modules.sys.controller.SysUserController.save()', '{\"userId\":2,\"username\":\"admin\",\"password\":\"25ab1953a35a7688fc17793901a03520971a77a0f0da1398de6b6afd0cc675d8\",\"salt\":\"maa92Y7epH3YvCEjPxH8\",\"email\":\"123@qq.com\",\"mobile\":\"123\",\"status\":1,\"roleIdList\":[3],\"createTime\":\"Sep 21, 2022 2:43:56 PM\",\"deptId\":1,\"deptName\":\"某某公司\"}', 12, '0:0:0:0:0:0:0:1', '2022-09-21 14:43:57');
INSERT INTO `sys_log` VALUES (10, 'dev', '保存用户', 'io.renren.modules.sys.controller.SysUserController.save()', '{\"userId\":3,\"username\":\"user\",\"password\":\"ec29e26fed4acae0eca24637552536dbb9823b07f95ada0e7fb26b40f4a0fe69\",\"salt\":\"EGx4TLVCbyw9GtMLPa5K\",\"email\":\"123@qq.com\",\"mobile\":\"123\",\"status\":1,\"roleIdList\":[2],\"createTime\":\"Sep 21, 2022 2:44:11 PM\",\"deptId\":1,\"deptName\":\"某某公司\"}', 10, '0:0:0:0:0:0:0:1', '2022-09-21 14:44:11');
INSERT INTO `sys_log` VALUES (11, 'dev', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '{\"menuId\":1,\"parentId\":0,\"parentName\":\"一级菜单\",\"name\":\"系统管理\",\"type\":0,\"icon\":\"fa fa-cog\",\"orderNum\":10}', 8, '0:0:0:0:0:0:0:1', '2022-09-21 15:28:29');
INSERT INTO `sys_log` VALUES (12, 'dev', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '{\"menuId\":51,\"parentId\":0,\"parentName\":\"一级菜单\",\"name\":\"薪资管理\",\"type\":0,\"icon\":\"fa fa-money\",\"orderNum\":0}', 8, '0:0:0:0:0:0:0:1', '2022-09-21 15:29:27');
INSERT INTO `sys_log` VALUES (13, 'dev', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '{\"menuId\":46,\"parentId\":51,\"parentName\":\"薪资管理\",\"name\":\"薪资表\",\"url\":\"modules/sys/salary.html\",\"type\":1,\"icon\":\"fa fa-file-code-o\",\"orderNum\":6}', 9, '0:0:0:0:0:0:0:1', '2022-09-21 15:29:42');
INSERT INTO `sys_log` VALUES (14, 'dev', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '{\"menuId\":52,\"parentId\":51,\"parentName\":\"薪资管理\",\"name\":\"个人薪资\",\"url\":\"modules/sys/personal.html\",\"type\":1,\"icon\":\"fa fa-user-circle\",\"orderNum\":0}', 6, '0:0:0:0:0:0:0:1', '2022-09-21 15:32:11');
INSERT INTO `sys_log` VALUES (15, 'dev', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '{\"menuId\":46,\"parentId\":51,\"parentName\":\"薪资管理\",\"name\":\"员工薪资\",\"url\":\"modules/sys/salary.html\",\"type\":1,\"icon\":\"fa fa-file-code-o\",\"orderNum\":6}', 8, '0:0:0:0:0:0:0:1', '2022-09-21 15:32:49');
INSERT INTO `sys_log` VALUES (16, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":2,\"roleName\":\"user\",\"remark\":\"普通用户\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[51,52],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:42:25 PM\"}', 114, '0:0:0:0:0:0:0:1', '2022-09-21 15:33:08');
INSERT INTO `sys_log` VALUES (17, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":3,\"roleName\":\"admin\",\"remark\":\"管理员\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[51,46,47,48,49,50,52],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:43:11 PM\"}', 19, '0:0:0:0:0:0:0:1', '2022-09-21 15:33:18');
INSERT INTO `sys_log` VALUES (18, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":3,\"roleName\":\"admin\",\"remark\":\"管理员\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[51,46,47,48,49,50],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:43:11 PM\"}', 12, '0:0:0:0:0:0:0:1', '2022-09-21 15:46:38');
INSERT INTO `sys_log` VALUES (19, 'dev', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '{\"userId\":3,\"username\":\"张三\",\"salt\":\"EGx4TLVCbyw9GtMLPa5K\",\"email\":\"123@qq.com\",\"mobile\":\"123\",\"status\":1,\"roleIdList\":[2],\"createTime\":\"Sep 21, 2022 2:44:11 PM\",\"deptId\":1,\"deptName\":\"某某公司\"}', 80, '0:0:0:0:0:0:0:1', '2022-09-22 09:53:43');
INSERT INTO `sys_log` VALUES (20, 'dev', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '{\"userId\":2,\"username\":\"管理员\",\"salt\":\"maa92Y7epH3YvCEjPxH8\",\"email\":\"123@qq.com\",\"mobile\":\"123\",\"status\":1,\"roleIdList\":[3],\"createTime\":\"Sep 21, 2022 2:43:57 PM\",\"deptId\":1,\"deptName\":\"某某公司\"}', 15, '0:0:0:0:0:0:0:1', '2022-09-22 09:53:52');
INSERT INTO `sys_log` VALUES (21, '张三', '修改密码', 'io.renren.modules.sys.controller.SysUserController.password()', '\"user\"', 20, '0:0:0:0:0:0:0:1', '2022-09-22 10:21:35');
INSERT INTO `sys_log` VALUES (22, 'dev', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '{\"userId\":3,\"username\":\"张三\",\"password\":\"ec29e26fed4acae0eca24637552536dbb9823b07f95ada0e7fb26b40f4a0fe69\",\"salt\":\"EGx4TLVCbyw9GtMLPa5K\",\"email\":\"123@qq.com\",\"mobile\":\"123\",\"status\":1,\"roleIdList\":[2],\"createTime\":\"Sep 21, 2022 2:44:11 PM\",\"deptId\":1,\"deptName\":\"某某公司\"}', 115, '0:0:0:0:0:0:0:1', '2022-09-22 10:22:26');
INSERT INTO `sys_log` VALUES (23, 'dev', '保存菜单', 'io.renren.modules.sys.controller.SysMenuController.save()', '{\"menuId\":53,\"parentId\":0,\"parentName\":\"一级菜单\",\"name\":\"找回密码\",\"url\":\"modules/sys/findPassword.html\",\"type\":1,\"icon\":\"fa fa-id-card\",\"orderNum\":3}', 12, '0:0:0:0:0:0:0:1', '2022-09-22 10:24:53');
INSERT INTO `sys_log` VALUES (24, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":2,\"roleName\":\"user\",\"remark\":\"普通用户\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[51,52,53],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:42:25 PM\"}', 58, '0:0:0:0:0:0:0:1', '2022-09-22 10:26:24');
INSERT INTO `sys_log` VALUES (25, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":3,\"roleName\":\"admin\",\"remark\":\"管理员\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[1,2,15,16,17,18,51,46,47,48,49,50],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:43:11 PM\"}', 99, '0:0:0:0:0:0:0:1', '2022-09-22 11:02:48');
INSERT INTO `sys_log` VALUES (26, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":3,\"roleName\":\"admin\",\"remark\":\"管理员\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[1,2,15,16,17,18,31,32,33,34,35,51,46,47,48,49,50],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:43:11 PM\"}', 41, '0:0:0:0:0:0:0:1', '2022-09-22 11:04:30');
INSERT INTO `sys_log` VALUES (27, '管理员', '修改用户', 'io.renren.modules.sys.controller.SysUserController.update()', '{\"userId\":1,\"username\":\"dev\",\"salt\":\"YzcmCZNvbXocrsz9dm8e\",\"email\":\"root@renren.io\",\"mobile\":\"13612345678\",\"status\":1,\"roleIdList\":[],\"createTime\":\"Nov 11, 2016 11:11:11 AM\",\"deptId\":1,\"deptName\":\"某某公司\",\"clerkNumber\":\"1\",\"name\":\"dev\",\"salaryCard\":\"001\",\"idCard\":\"123\"}', 37, '0:0:0:0:0:0:0:1', '2022-09-22 11:04:54');
INSERT INTO `sys_log` VALUES (28, 'dev', '修改角色', 'io.renren.modules.sys.controller.SysRoleController.update()', '{\"roleId\":3,\"roleName\":\"admin\",\"remark\":\"管理员\",\"deptId\":1,\"deptName\":\"某某公司\",\"menuIdList\":[1,2,15,16,17,18,31,32,33,34,35,54,55,56,57,58,51,46,47,48,49,50],\"deptIdList\":[1],\"createTime\":\"Sep 21, 2022 2:43:11 PM\"}', 72, '0:0:0:0:0:0:0:1', '2022-09-28 15:37:29');
INSERT INTO `sys_log` VALUES (29, 'dev', '修改菜单', 'io.renren.modules.sys.controller.SysMenuController.update()', '{\"menuId\":54,\"parentId\":1,\"parentName\":\"系统管理\",\"name\":\"工资项管理\",\"url\":\"modules/sys/sysitem.html\",\"type\":1,\"icon\":\"fa fa-file-code-o\",\"orderNum\":6}', 6, '0:0:0:0:0:0:0:1', '2022-09-28 15:37:58');
INSERT INTO `sys_log` VALUES (30, 'dev', '删除菜单', 'io.renren.modules.sys.controller.SysMenuController.delete()', '53', 20, '0:0:0:0:0:0:0:1', '2022-09-28 22:31:34');

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NULL DEFAULT NULL COMMENT '父菜单ID，一级菜单为0',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单名称',
  `url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单URL',
  `perms` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` int(11) NULL DEFAULT NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单图标',
  `order_num` int(11) NULL DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '菜单管理' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, 0, '系统管理', NULL, NULL, 0, 'fa fa-cog', 10);
INSERT INTO `sys_menu` VALUES (2, 1, '用户管理', 'modules/sys/user.html', NULL, 1, 'fa fa-user', 1);
INSERT INTO `sys_menu` VALUES (3, 1, '角色管理', 'modules/sys/role.html', NULL, 1, 'fa fa-user-secret', 2);
INSERT INTO `sys_menu` VALUES (4, 1, '菜单管理', 'modules/sys/menu.html', NULL, 1, 'fa fa-th-list', 3);
INSERT INTO `sys_menu` VALUES (5, 1, 'SQL监控', 'druid/sql.html', NULL, 1, 'fa fa-bug', 4);
INSERT INTO `sys_menu` VALUES (15, 2, '查看', NULL, 'sys:user:list,sys:user:info', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (16, 2, '新增', NULL, 'sys:user:save,sys:role:select', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (17, 2, '修改', NULL, 'sys:user:update,sys:role:select', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (18, 2, '删除', NULL, 'sys:user:delete', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (19, 3, '查看', NULL, 'sys:role:list,sys:role:info', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (20, 3, '新增', NULL, 'sys:role:save,sys:menu:perms', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (21, 3, '修改', NULL, 'sys:role:update,sys:menu:perms', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (22, 3, '删除', NULL, 'sys:role:delete', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (23, 4, '查看', NULL, 'sys:menu:list,sys:menu:info', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (24, 4, '新增', NULL, 'sys:menu:save,sys:menu:select', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (25, 4, '修改', NULL, 'sys:menu:update,sys:menu:select', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (26, 4, '删除', NULL, 'sys:menu:delete', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (27, 1, '参数管理', 'modules/sys/config.html', 'sys:config:list,sys:config:info,sys:config:save,sys:config:update,sys:config:delete', 1, 'fa fa-sun-o', 6);
INSERT INTO `sys_menu` VALUES (29, 1, '系统日志', 'modules/sys/log.html', 'sys:log:list', 1, 'fa fa-file-text-o', 7);
INSERT INTO `sys_menu` VALUES (31, 1, '部门管理', 'modules/sys/dept.html', NULL, 1, 'fa fa-file-code-o', 1);
INSERT INTO `sys_menu` VALUES (32, 31, '查看', NULL, 'sys:dept:list,sys:dept:info', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (33, 31, '新增', NULL, 'sys:dept:save,sys:dept:select', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (34, 31, '修改', NULL, 'sys:dept:update,sys:dept:select', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (35, 31, '删除', NULL, 'sys:dept:delete', 2, NULL, 0);
INSERT INTO `sys_menu` VALUES (36, 1, '字典管理', 'modules/sys/dict.html', NULL, 1, 'fa fa-bookmark-o', 6);
INSERT INTO `sys_menu` VALUES (37, 36, '查看', NULL, 'sys:dict:list,sys:dict:info', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (38, 36, '新增', NULL, 'sys:dict:save', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (39, 36, '修改', NULL, 'sys:dict:update', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (40, 36, '删除', NULL, 'sys:dict:delete', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (46, 51, '员工薪资', 'modules/sys/salary.html', NULL, 1, 'fa fa-file-code-o', 6);
INSERT INTO `sys_menu` VALUES (47, 46, '查看', NULL, 'sys:salary:list,sys:salary:info', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (48, 46, '新增', NULL, 'sys:salary:save', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (49, 46, '修改', NULL, 'sys:salary:update', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (50, 46, '删除', NULL, 'sys:salary:delete', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (51, 0, '薪资管理', NULL, NULL, 0, 'fa fa-money', 0);
INSERT INTO `sys_menu` VALUES (52, 51, '个人薪资', 'modules/sys/personal.html', NULL, 1, 'fa fa-user-circle', 0);
INSERT INTO `sys_menu` VALUES (54, 1, '工资项管理', 'modules/sys/sysitem.html', NULL, 1, 'fa fa-file-code-o', 6);
INSERT INTO `sys_menu` VALUES (55, 54, '查看', NULL, 'sys:sysitem:list,sys:sysitem:info', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (56, 54, '新增', NULL, 'sys:sysitem:save', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (57, 54, '修改', NULL, 'sys:sysitem:update', 2, NULL, 6);
INSERT INTO `sys_menu` VALUES (58, 54, '删除', NULL, 'sys:sysitem:delete', 2, NULL, 6);

-- ----------------------------
-- Table structure for sys_oss
-- ----------------------------
DROP TABLE IF EXISTS `sys_oss`;
CREATE TABLE `sys_oss`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'URL地址',
  `create_date` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '文件上传' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_oss
-- ----------------------------

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `dept_id` bigint(20) NULL DEFAULT NULL COMMENT '部门ID',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (2, 'user', '普通用户', 1, '2022-09-21 14:42:25');
INSERT INTO `sys_role` VALUES (3, 'admin', '管理员', 1, '2022-09-21 14:43:11');

-- ----------------------------
-- Table structure for sys_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色ID',
  `dept_id` bigint(20) NULL DEFAULT NULL COMMENT '部门ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色与部门对应关系' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_role_dept
-- ----------------------------
INSERT INTO `sys_role_dept` VALUES (8, 2, 1);
INSERT INTO `sys_role_dept` VALUES (11, 3, 1);

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NULL DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 142 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色与菜单对应关系' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (88, 2, 51);
INSERT INTO `sys_role_menu` VALUES (89, 2, 52);
INSERT INTO `sys_role_menu` VALUES (120, 3, 1);
INSERT INTO `sys_role_menu` VALUES (121, 3, 2);
INSERT INTO `sys_role_menu` VALUES (122, 3, 15);
INSERT INTO `sys_role_menu` VALUES (123, 3, 16);
INSERT INTO `sys_role_menu` VALUES (124, 3, 17);
INSERT INTO `sys_role_menu` VALUES (125, 3, 18);
INSERT INTO `sys_role_menu` VALUES (126, 3, 31);
INSERT INTO `sys_role_menu` VALUES (127, 3, 32);
INSERT INTO `sys_role_menu` VALUES (128, 3, 33);
INSERT INTO `sys_role_menu` VALUES (129, 3, 34);
INSERT INTO `sys_role_menu` VALUES (130, 3, 35);
INSERT INTO `sys_role_menu` VALUES (131, 3, 54);
INSERT INTO `sys_role_menu` VALUES (132, 3, 55);
INSERT INTO `sys_role_menu` VALUES (133, 3, 56);
INSERT INTO `sys_role_menu` VALUES (134, 3, 57);
INSERT INTO `sys_role_menu` VALUES (135, 3, 58);
INSERT INTO `sys_role_menu` VALUES (136, 3, 51);
INSERT INTO `sys_role_menu` VALUES (137, 3, 46);
INSERT INTO `sys_role_menu` VALUES (138, 3, 47);
INSERT INTO `sys_role_menu` VALUES (139, 3, 48);
INSERT INTO `sys_role_menu` VALUES (140, 3, 49);
INSERT INTO `sys_role_menu` VALUES (141, 3, 50);

-- ----------------------------
-- Table structure for sys_salary
-- ----------------------------
DROP TABLE IF EXISTS `sys_salary`;
CREATE TABLE `sys_salary`  (
  `salary_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `clerk_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '职工号',
  `clerk_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工姓名',
  `year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '年',
  `month` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '月',
  `base_salary` decimal(10, 2) NULL DEFAULT NULL COMMENT '基本工资',
  `course_fee` decimal(10, 0) NULL DEFAULT NULL COMMENT '课时费',
  `base_perform` decimal(10, 0) NULL DEFAULT NULL COMMENT '基础绩效',
  `age_salary` decimal(10, 2) NULL DEFAULT NULL COMMENT '工龄工资',
  `call_subsidies` decimal(10, 2) NULL DEFAULT NULL COMMENT '电话补助',
  `traffic_subsidies` decimal(10, 0) NULL DEFAULT NULL COMMENT '交通补助',
  `overtime_subsidies` decimal(10, 0) NULL DEFAULT NULL COMMENT '加班补助',
  `labor_insurance` decimal(10, 0) NULL DEFAULT NULL COMMENT '劳动保险',
  `unemployment_insurance` decimal(10, 0) NULL DEFAULT NULL COMMENT '失业保险',
  `medical_insurance` decimal(10, 0) NULL DEFAULT NULL COMMENT '医疗保险',
  `personal_tax` decimal(10, 0) NULL DEFAULT NULL COMMENT '个人税',
  `accumulation_fund` decimal(10, 0) NULL DEFAULT NULL COMMENT '扣公积金',
  `pay_total` decimal(10, 0) NULL DEFAULT NULL COMMENT '应发合计',
  `deduct_total` decimal(10, 0) NULL DEFAULT NULL COMMENT '扣款合计',
  `real_wages` decimal(10, 0) NULL DEFAULT NULL COMMENT '实发工资',
  `full_date` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `additional` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`salary_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '薪资表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_salary
-- ----------------------------
INSERT INTO `sys_salary` VALUES (1, '001', '张三', '2022', '02', 1000.00, 1000, 1000, 1000.00, 1000.00, 1000, 1000, 100, 100, 100, 100, 100, 7000, 500, 6500, '2022-02', NULL);
INSERT INTO `sys_salary` VALUES (2, '002', 'yzy01', '2022', '02', 1000.00, 1000, 1000, 1000.00, 1000.00, 1000, 1000, 100, 100, 100, 100, 100, 7000, 500, 6500, '2022-02', NULL);
INSERT INTO `sys_salary` VALUES (3, '003', '张三', '2022', '09', 1000.00, 1000, 1000, 1000.00, 1000.00, 1000, 1000, 100, 100, 100, 100, 100, 7000, 500, 6500, '2022-09', NULL);
INSERT INTO `sys_salary` VALUES (4, '001', 'as', '2022', '12', 112.00, 112, 112, 112.00, 112.00, 112, 112, 112, 112, 112, 112, 112, 784, 560, 224, '2022-12', '233333,');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '密码',
  `salt` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '盐',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `dept_id` bigint(20) NULL DEFAULT NULL COMMENT '部门ID',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `clerk_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '职工号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `salary_card` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工资卡号',
  `id_card` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '身份证号',
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统用户' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'dev', '1e4730675f1e46f44e1f4cc85a285f1f2cca2d7fbb344d552c0dc34aa89e148a', 'YzcmCZNvbXocrsz9dm8e', 'root@renren.io', '13612345678', 1, 1, '2016-11-11 11:11:11', '1', 'dev', '001', '123');
INSERT INTO `sys_user` VALUES (2, '管理员', '25ab1953a35a7688fc17793901a03520971a77a0f0da1398de6b6afd0cc675d8', 'maa92Y7epH3YvCEjPxH8', '123@qq.com', '123', 1, 1, '2022-09-21 14:43:57', '2', '管理员', '002', '345');
INSERT INTO `sys_user` VALUES (3, '张三', 'ec29e26fed4acae0eca24637552536dbb9823b07f95ada0e7fb26b40f4a0fe69', 'EGx4TLVCbyw9GtMLPa5K', '123@qq.com', '123', 1, 1, '2022-09-21 14:44:11', '3', '张三', '003', '567');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户与角色对应关系' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (4, 2, 3);
INSERT INTO `sys_user_role` VALUES (5, 3, 2);

SET FOREIGN_KEY_CHECKS = 1;
