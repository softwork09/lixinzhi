package io.renren.modules.sys.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.sys.dao.SysItemDao;
import io.renren.modules.sys.entity.SysItemEntity;
import io.renren.modules.sys.service.SysItemService;


@Service("sysItemService")
public class SysItemServiceImpl extends ServiceImpl<SysItemDao, SysItemEntity> implements SysItemService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<SysItemEntity> page = this.page(
                new Query<SysItemEntity>().getPage(params),
                new QueryWrapper<SysItemEntity>()
        );

        return new PageUtils(page);
    }

}
