package io.renren.modules.sys.service.impl;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import io.renren.modules.sys.dao.SalaryDao;
import io.renren.modules.sys.entity.SalaryEntity;
import io.renren.modules.sys.service.SalaryService;


@Service("salaryService")
public class SalaryServiceImpl extends ServiceImpl<SalaryDao, SalaryEntity> implements SalaryService {

    public boolean judgeIfYear(String str) {
        return str.length() == 4;
    }

    public boolean judgeIfMonth(String str) {
        return str.length() == 7;
    }

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        String key = (String)params.get("key");

        String clerkName = (String)params.get("clerkName");

        String begin = (String)params.get("begin");
        String end = (String)params.get("end");

        QueryWrapper<SalaryEntity> wrapper = new QueryWrapper<>();

        if (StringUtils.isNotBlank(clerkName)) {
            wrapper.eq("clerk_name", clerkName)
                    .and(StringUtils.isNotBlank(key), queryWrapper -> queryWrapper
                            .or().like(StringUtils.isNotBlank(key) && judgeIfMonth(key), "full_date", key)
                    .or().like(StringUtils.isNotBlank(key) && judgeIfYear(key), "year", key));
            if (StringUtils.isNotBlank(begin) && StringUtils.isNotBlank(end)) {
                wrapper.between("full_date", begin, end);
            }
        } else {
            wrapper.like(StringUtils.isNotBlank(key) && judgeIfMonth(key), "full_date", key)
                    .or().like(StringUtils.isNotBlank(key), "clerk_name", key)
                    .or().like(StringUtils.isNotBlank(key), "clerk_number", key);
        }


        IPage<SalaryEntity> page = this.page(
                new Query<SalaryEntity>().getPage(params),
               wrapper
        );
        for (SalaryEntity record : page.getRecords()) {
            record.setDate(record.getYear() + '-' + record.getMonth());
        }

        return new PageUtils(page);
    }

    @Override
    public void delByMonth(String month) {
        QueryWrapper<SalaryEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(StringUtils.isNotBlank(month),"month", month);
        remove(queryWrapper);
    }

}
