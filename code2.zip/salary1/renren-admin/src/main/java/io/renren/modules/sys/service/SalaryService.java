package io.renren.modules.sys.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.sys.entity.SalaryEntity;

import java.util.Map;

/**
 * 薪资表
 *
 * @author 
 * @email 
 * @date 2022-09-21 15:24:17
 */
public interface SalaryService extends IService<SalaryEntity> {

    PageUtils queryPage(Map<String, Object> params);

    void delByMonth(String month);
}

