package io.renren.modules.sys.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.io.Serializable;
import java.util.Date;

/**
 * 薪资表
 * 
 * @author 
 * @email 
 * @date 2022-09-21 15:24:17
 */
@Data
@TableName("sys_salary")
public class SalaryEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	private String additional;

	/**
	 * id
	 */
	@TableId
	private Integer salaryId;

	private String fullDate;
	/**
	 * 职工号
	 */
	private String clerkNumber;
	private String clerkName;
	/**
	 * 年
	 */
	private String year;
	/**
	 * 月
	 */
	private String month;

	@TableField(exist = false)
	private String date;
	/**
	 * 基本工资
	 */
	private BigDecimal baseSalary;
	/**
	 * 课时费
	 */
	private BigDecimal courseFee;
	/**
	 * 基础绩效
	 */
	private BigDecimal basePerform;
	/**
	 * 工龄工资
	 */
	private BigDecimal ageSalary;
	/**
	 * 电话补助
	 */
	private BigDecimal callSubsidies;
	/**
	 * 交通补助
	 */
	private BigDecimal trafficSubsidies;
	/**
	 * 加班补助
	 */
	private BigDecimal overtimeSubsidies;
	/**
	 * 劳动保险
	 */
	private BigDecimal laborInsurance;
	/**
	 * 失业保险
	 */
	private BigDecimal unemploymentInsurance;
	/**
	 * 医疗保险
	 */
	private BigDecimal medicalInsurance;
	/**
	 * 个人税
	 */
	private BigDecimal personalTax;
	/**
	 * 扣公积金
	 */
	private BigDecimal accumulationFund;
	/**
	 * 应发合计
	 */
	private BigDecimal payTotal;
	/**
	 * 扣款合计
	 */
	private BigDecimal deductTotal;
	/**
	 * 实发工资
	 */
	private BigDecimal realWages;

}
