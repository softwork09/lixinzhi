package io.renren.modules.sys.controller;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;

import io.renren.common.validator.ValidatorUtils;
import io.renren.modules.sys.entity.SysUserEntity;
import io.renren.modules.sys.shiro.ShiroUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.sys.entity.SalaryEntity;
import io.renren.modules.sys.service.SalaryService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 薪资表
 *
 * @author 
 * @email 
 * @date 2022-09-21 15:24:17
 */
@RestController
@RequestMapping("sys/salary")
public class SalaryController {
    @Autowired
    private SalaryService salaryService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:salary:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = salaryService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{salaryId}")
    @RequiresPermissions("sys:salary:info")
    public R info(@PathVariable("salaryId") Integer salaryId){
        SalaryEntity salary = salaryService.getById(salaryId);

        return R.ok().put("salary", salary);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("sys:salary:save")
    public R save(@RequestBody SalaryEntity salary){
        BigDecimal payTotal = new BigDecimal(0);
        payTotal = payTotal.add(salary.getBaseSalary())
                .add(salary.getCourseFee())
                .add(salary.getBasePerform())
                .add(salary.getAgeSalary())
                .add(salary.getCallSubsidies())
                .add(salary.getTrafficSubsidies())
                .add(salary.getOvertimeSubsidies());
        BigDecimal deductTotal = new BigDecimal(0);
        deductTotal = deductTotal.add(salary.getLaborInsurance())
                .add(salary.getUnemploymentInsurance())
                .add(salary.getMedicalInsurance())
                .add(salary.getPersonalTax())
                .add(salary.getAccumulationFund());
        BigDecimal realWages = new BigDecimal(0);
        realWages = payTotal.subtract(deductTotal);
        salary.setPayTotal(payTotal);
        salary.setDeductTotal(deductTotal);
        salary.setRealWages(realWages);

        salary.setFullDate(salary.getYear() + "-" + salary.getMonth());

        salaryService.save(salary);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("sys:salary:update")
    public R update(@RequestBody SalaryEntity salary){
        ValidatorUtils.validateEntity(salary);
        BigDecimal payTotal = new BigDecimal(0);
        payTotal = payTotal.add(salary.getBaseSalary())
                .add(salary.getCourseFee())
                .add(salary.getBasePerform())
                .add(salary.getAgeSalary())
                .add(salary.getCallSubsidies())
                .add(salary.getTrafficSubsidies())
                .add(salary.getOvertimeSubsidies());
        BigDecimal deductTotal = new BigDecimal(0);
        deductTotal = deductTotal.add(salary.getLaborInsurance())
                .add(salary.getUnemploymentInsurance())
                .add(salary.getMedicalInsurance())
                .add(salary.getPersonalTax())
                .add(salary.getAccumulationFund());
        BigDecimal realWages = new BigDecimal(0);
        realWages = payTotal.subtract(deductTotal);
        salary.setPayTotal(payTotal);
        salary.setDeductTotal(deductTotal);
        salary.setRealWages(realWages);

        salary.setFullDate(salary.getYear() + "-" + salary.getMonth());

        salaryService.updateById(salary);
        
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("sys:salary:delete")
    public R delete(@RequestBody Integer[] salaryIds){
        salaryService.removeByIds(Arrays.asList(salaryIds));

        return R.ok();
    }

    @RequestMapping("/delByMonth/{month}")
    public R delByMonth(@PathVariable("month") String month){
        salaryService.delByMonth(month);

        return R.ok();
    }

    /**
     * 列表
     */
    @RequestMapping("/listPersonal")
    public R listPersonal(@RequestParam Map<String, Object> params){

        SysUserEntity userEntity = ShiroUtils.getUserEntity();
        params.put("clerkName", userEntity.getUsername());

        PageUtils page = salaryService.queryPage(params);

        return R.ok().put("page", page);
    }

}
