package io.renren.modules.sys.dao;

import io.renren.modules.sys.entity.SalaryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 薪资表
 * 
 * @author 
 * @email 
 * @date 2022-09-21 15:24:17
 */
@Mapper
public interface SalaryDao extends BaseMapper<SalaryEntity> {
	
}
