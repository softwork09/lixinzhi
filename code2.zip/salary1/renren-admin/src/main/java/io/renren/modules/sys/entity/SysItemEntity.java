package io.renren.modules.sys.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 工资项
 * 
 * @author Mark
 * @email sunlightcs@gmail.com
 * @date 2022-09-28 15:35:07
 */
@Data
@TableName("sys_item")
public class SysItemEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId
	private Integer id;
	/**
	 * 工资项
	 */
	private String itemName;

}
