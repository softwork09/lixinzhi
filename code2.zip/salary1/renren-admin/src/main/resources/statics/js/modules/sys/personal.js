$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + 'sys/salary/listPersonal',
        datatype: "json",
        colModel: [
            { label: '职工号', name: 'clerkNumber', index: 'clerk_number', width: 80 },
            { label: '职工姓名', name: 'clerkName', index: 'clerk_name', width: 80 },
			{ label: '时间', name: 'date', index: 'date', width: 80 },
			{ label: '基本工资', name: 'baseSalary', index: 'base_salary', width: 80 },
			{ label: '课时费', name: 'courseFee', index: 'course_fee', width: 80 }, 			
			{ label: '基础绩效', name: 'basePerform', index: 'base_perform', width: 80 }, 			
			{ label: '工龄工资', name: 'ageSalary', index: 'age_salary', width: 80 }, 			
			{ label: '电话补助', name: 'callSubsidies', index: 'call_subsidies', width: 80 }, 			
			{ label: '交通补助', name: 'trafficSubsidies', index: 'traffic_subsidies', width: 80 }, 			
			{ label: '加班补助', name: 'overtimeSubsidies', index: 'overtime_subsidies', width: 80 }, 			
			{ label: '劳动保险', name: 'laborInsurance', index: 'labor_insurance', width: 80 },
			{ label: '失业保险', name: 'unemploymentInsurance', index: 'unemployment_insurance', width: 80 }, 			
			{ label: '医疗保险', name: 'medicalInsurance', index: 'medical__insurance', width: 80 }, 			
			{ label: '个人税', name: 'personalTax', index: 'personal_tax', width: 80 }, 			
			{ label: '扣公积金', name: 'accumulationFund', index: 'accumulation_fund', width: 80 }, 			
			{ label: '应发合计', name: 'payTotal', index: 'pay_total', width: 80 }, 			
			{ label: '扣款合计', name: 'deductTotal', index: 'deduct_total', width: 80 }, 			
			{ label: '实发工资', name: 'realWages', index: 'real_wages', width: 80 }			
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

var vm = new Vue({
	el:'#rrapp',
	data:{
		showList: true,
		title: null,
		salary: {},

        q:{
            key: null
        },
	},
	methods: {

		query: function () {
			vm.reload();
		},
		getInfo: function(salaryId){
			$.get(baseURL + "sys/salary/info/"+salaryId, function(r){
                vm.salary = r.salary;
            });
		},
		reload: function (event) {
			vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{
                postData:{'key': vm.q.key, 'begin':vm.q.begin, 'end': vm.q.end},
                page:page
            }).trigger("reloadGrid");
		}
	}
});