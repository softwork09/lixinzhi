var vm = new Vue({
	el:'#rrapp',
	data:{
		user: {}
	},
	methods: {

		findPassword: function(){
			$.getJSON('/renren-admin/sys/user/findPassword/' + vm.user.idCard + '/' + vm.user.salaryCard+ '/' + vm.user.newPassword, function (res) {
				if (res.code == 0) {
					alert('修改成功！' )
				} else {
					alert(res.msg)
				}
			})
		}
	}
});